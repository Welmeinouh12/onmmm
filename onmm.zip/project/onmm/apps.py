from django.apps import AppConfig


class OnmmConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'onmm'
