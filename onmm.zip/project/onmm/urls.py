from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('formulaire/', views.formulaire, name='formulaire'),
    path('education/', views.education, name='education'),
    path('educationMD/', views.educationMD, name='educationMD'),
    path('Exprience/', views.Exprience, name='Exprience'),
    path('ExprienceMD/', views.ExprienceMD, name='ExprienceMD'),
    path('document/', views.document, name='document'),
    path('declaration/', views.declaration, name='declaration'),
    path('contacter/', views.contacter, name='contacter'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('gestion_du_demende/', views.gestion_du_demende, name='gestion_du_demende'),
    path('details_demande/', views.details_demande, name='details_demande'),  
    path('g_medecins/', views.g_medecins, name='g_medecins'),
    path('details_medecin/', views.details_medecin, name='details_medecin'), 
    path('paramrtre/', views.paramrtre, name='paramrtre'),
    path('galarie/', views.galarie, name='galarie'),  
    path('log/', views.log, name='log'),  
]