from django.db import models
from django.contrib.auth.models import AbstractUser

class Utilisateur(AbstractUser):
    TYPE_CHOICES = (
        ('normal', 'UtilisateurNormal'),
        ('medecin', 'Medecin'),
        ('admin', 'Administrateur'),
    )
    # username = None  
    nom = models.CharField( max_length=100, null=False, blank=False)
    nni = models.CharField( max_length=20, unique=True, null=True, blank=True)
    phone = models.CharField( max_length=15, unique=True, null=True, blank=True)
    genre = models.CharField( max_length=10, choices=(('Homme', 'Homme'), ('Femme', 'Femme')), default='Homme')
    email = models.EmailField(unique=True)
    date_inscription = models.DateTimeField(auto_now_add=True)
    date_naiss = models.DateField(null=True, blank=True)
    type= models.CharField(choices=TYPE_CHOICES, default='normal')
    adresse = models.CharField(max_length=255, null=True, blank=True)
    
    

    class Meta:
        verbose_name = "utilisateur"
        verbose_name_plural = "utilisateurs"

    def __str__(self):
        return self.nom

    def is_admin(self):
        return self.type == 'admin'

    def is_medecin(self):
        return self.type == 'medecin'

    def is_normal(self):
        return self.type == 'normal'
    def __str__(self):
        return self.username
    
class Education(models.Model):
    utilisateur = models.ForeignKey(Utilisateur, on_delete=models.CASCADE, related_name='educations' )
    specialite = models.CharField(max_length=100)
    sous_specialite = models.CharField(max_length=100, blank=True, null=True)
    diplome_obtenu = models.CharField(max_length=100)
    annee_obtention_diplome = models.DateField()
    pays = models.CharField(max_length=100)
    ville = models.CharField(max_length=100)
    nom_universite_etablissement = models.CharField(max_length=200)

    class Meta:
        verbose_name = "éducation"
        verbose_name_plural = "éducations"

    def __str__(self):
        return f"{self.specialite} - {self.utilisateur.username}"
    
class Experience(models.Model):
    utilisateur = models.ForeignKey(Utilisateur, on_delete=models.CASCADE, related_name='experiences')
    poste = models.CharField(max_length=100)
    entreprise = models.CharField(max_length=100)
    date_debut = models.DateField()
    date_fin = models.DateField(null=True, blank=True)
    description = models.TextField()
 
    class Meta:
        verbose_name = "expérience"
        verbose_name_plural = "expériences"

    def __str__(self):
        return f"{self.poste} chez {self.entreprise} - {self.utilisateur.username}"    

class Demande(models.Model):
    STATUT_CHOICES = (
        ('en_attente', 'En attente'),
        ('en_cours', 'En cours'),
        ('terminee', 'Terminée'),
        ('annulee', 'Annulée'),
    )
 
    utilisateur = models.ForeignKey(Utilisateur, on_delete=models.CASCADE)
    date_demande = models.DateTimeField(auto_now_add=True)
    date_traitement = models.DateTimeField(null=True, blank=True)
    statut = models.CharField(choices=STATUT_CHOICES, default='en_attente')
    details = models.TextField()

    class Meta:
        verbose_name = "demande"
        verbose_name_plural = "demandes"

    def __str__(self):
        return f"Demande de {self.utilisateur.nom} - {self.statut}"
    
     