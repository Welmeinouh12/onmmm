from django.shortcuts import render
from django.http import HttpResponse
from .models import Demande, Utilisateur, Education, Experience
# Create your views here.
def home(request):
    
    return render(request, 'onmm/home.html')
def log(request):
    return render(request, 'onmm/log.html')

def formulaire(request):
    if request.method == 'POST':
        nom = request.POST.get('name')
        email = request.POST.get('email')
        date_naiss = request.POST.get('date_naiss')
        type_utilisateur = request.POST.get('type_utilisateur') 
        genre = request.POST.get('genre')
        nni = request.POST.get('nni')
        phone = request.POST.get('phone')

        # Vous pouvez ajouter ici la logique pour enregistrer ces données dans la base de données
        utilisateur = Utilisateur(
            username=nom,
            email=email,
            date_naiss=date_naiss,
            type=type_utilisateur,
            genre=genre,
            nni=nni,
            phone=phone
        )
        utilisateur.save()  # Enregistrer l'utilisateur dans la base de données

        # Ici, vous pouvez enregistrer les données dans la base de données si nécessaire

        return HttpResponse("Formulaire soumis avec succès !")
    else:
        context = {
            'types': ['normal', 'medecin', 'admin']  # Types d'utilisateur, à ajuster si besoin
        }
        return render(request, 'onmm/formulaire.html', context)

def education(request):
    
    return render(request, 'onmm/education.html')

def educationMD(request):
    return render(request, 'onmm/educationMD.html')

def Exprience(request):
    return render(request, 'onmm/Exprience.html')
def ExprienceMD(request):
    return render(request, 'onmm/ExprienceMD.html')

def document(request):
    return render(request, 'onmm/document.html')

def declaration(request):
    if request.method == 'POST':
        # Traitez les données du formulaire ici
        # Exemple : Vous pouvez récupérer les champs du formulaire avec request.POST.get('nom_du_champ')
        # Ajoutez ici votre logique de traitement du formulaire
        pass
        # Exemple de données de contexte, à ajuster selon vos besoins
    context = {
        'documents': ['Document 1', 'Document 2', 'Document 3']
    }
    return render(request, 'onmm/declaration.html', context)

def contacter(request):
    return render(request, 'onmm/contacter.html')
def dashboard(request):
    demandes = Demande.objects.all()
    data = {
        'demandes': demandes,
        'total_demandes': demandes.count(),
        'en_attente': demandes.filter(statut='en_attente').count(),
        'en_cours': demandes.filter(statut='en_cours').count(),
        'terminees': demandes.filter(statut='terminee').count(),
        'annulees': demandes.filter(statut='annulee').count(),
    }
    return render(request, 'onmm/dashboard.html', data)
def gestion_du_demende(request):
    demandes = Demande.objects.all()
    data = {
        'demandes': demandes,
        'total_demandes': demandes.count(),
        'en_attente': demandes.filter(statut='en_attente').count(),
        'en_cours': demandes.filter(statut='en_cours').count(),
        'terminees': demandes.filter(statut='terminee').count(),
        'annulees': demandes.filter(statut='annulee').count(),
    }
    return render(request, 'onmm/gestion_du_demende.html', data)


def details_demande(request):
    demande_id = request.GET.get('id')
    try:    
        demande = Demande.objects.get(id=demande_id)
        data = {
            'demande': demande,
        }
    except Demande.DoesNotExist:
        data = {
            'error': 'Demande not found.'
        }

    return render(request, 'onmm/details_demande.html')
def g_medecins(request):
    return render(request, 'onmm/g_medecins.html')
def details_medecin(request):
    return render(request, 'onmm/details_medecin.html')
def paramrtre(request):
    return render(request, 'onmm/parametre.html')
def galarie(request):
    return render(request, 'onmm/galarie.html')