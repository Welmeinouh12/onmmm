document.getElementById('submitBtn').addEventListener('click', function() {
  const dossier = document.getElementById('dossier').value;
  if (dossier.trim() === "") {
    alert('Veuillez entrer votre numéro de dossier.');
  } else {
    alert('Dossier soumis : ' + dossier);
    // Ici, vous pouvez ajouter la logique pour soumettre le dossier
  }
});